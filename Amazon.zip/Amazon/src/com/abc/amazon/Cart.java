package com.abc.amazon;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Cart {

	static double grandTotal = 0;
	public static void showCart() {
		Amazon.header();
		System.out.println();
		char option;
		System.out.println();
		System.out.printf("%30s %n","                                     <-------------------------- AMAZON CART ---------------------------->               ");
		System.out.println();



		System.out.println("           --------------------------------------------------------------------------------------------------------------------------               ");
		System.out.printf("%21s %20s %46s %14s %12s %12s %n%n","ITEM CODE","PRODUCT NAME","CATEGORY","PRICE", "QUANTITY","TOTAL");
		System.out.println("           --------------------------------------------------------------------------------------------------------------------------               ");

		int i=1;
		Set set = Amazon.cart.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) {
			Map.Entry mentry = (Map.Entry)iterator.next();
			String[] value=((String)mentry.getValue()).split("@");
			double total=  Double.parseDouble(value[3]) *Double.parseDouble(value[4]);
			grandTotal+=total;
			System.out.format("%21s %-60s %-15s %-12s %-13s %-1s %n", i+"     ", value[0] ,value[2] ,"Rs."+value[3],value[4],total);
			i++;
		}
		System.out.println();
		System.out.println("           --------------------------------------------------------------------------------------------------------------------------               ");
		System.out.printf("%120s %n","Grand Total : "+grandTotal+ " (without %GST)");
		System.out.println("           --------------------------------------------------------------------------------------------------------------------------               ");
		System.out.println();
		System.out.println();
		System.out.println("=> Press U : Update an item from cart");
		System.out.println("=> Press D : Delete an item from cart");
		System.out.println("=> Press C : Continue Shopping");
		System.out.println("=> Press E : Check out");
		System.out.println();
		System.out.println("Please select an Item");
		option=Amazon.scn.next().charAt(0);
		if(option=='U' ||option=='u' ) {
			updateCart();
			showCart();
		}
		else if(option=='D' ||option=='d' ) {
			deleteCart();
			showCart();
		}
		else if(option=='C' ||option=='c' ) {
			Amazon.firstView();
		}
		else if(option=='E' ||option=='e' ) {
			if(Amazon.cart.size()>0)
			Bill.Bill1();
			else
			System.out.println("Thank you for visting Amazon!!!");
			System.exit(0);
		}
		else if(option=='#') {
			Amazon.firstView();
		}
		else if(option=='@') {
			Amazon.exit();
		}
		else {
			System.err.println("ERROR : Invalid Option Selected!!!");

			showCart();
		}
	}

	private static void deleteCart() {
		System.out.println("Enter the Item Code to be deleted");
		char code=Amazon.scn.next().charAt(0);

		String keyInfo = null;
		int j=1;
		// Keys of HashMap
		for ( String key : Amazon.cart.keySet() ) {
			if(j==Character.getNumericValue(code)) {
				keyInfo=key;
				break;
			}
			j++;
		} 

		if(Amazon.cart.containsKey(keyInfo)){
			byte confirm;
			System.out.println("Do you want to Remove Item - "+keyInfo+" from cart?");
			System.out.println("Press 1.YES 2.NO");
			confirm=Amazon.scn.nextByte();
			if(confirm==1) {
				Amazon.cart.remove(keyInfo);
				Cart.showCart();
				System.out.println("Item Removed from the cart!!!");
			}
			else if(confirm==2)
				Cart.showCart();
			else {
				System.err.println("Invalid Option Choosen!!!");
				Cart.showCart();
			}
		}
		else {
			System.err.println("This Item Code not found in your cart!!!");
			Cart.showCart();
		}
	}

	private static void updateCart() {
		System.out.println("Enter the Item Code of which Quantity needs to be update");
		char code=Amazon.scn.next().charAt(0);
		System.out.println("Enter the new Quantity");
		String qty=Amazon.scn.next();
		String keyInfo = null;
		int j=1;
		// Keys of HashMap
		for ( String key : Amazon.cart.keySet() ) {
			if(j==Character.getNumericValue(code)) {
				keyInfo=key;
				break;
			}
			j++;
		}
		
		if(Amazon.cart.containsKey(keyInfo)){
			
			if(Integer.parseInt(qty)>0) {
				String itemInfo[]=Amazon.cart.get(keyInfo).split("@");
				itemInfo[4]=qty;
				String newValues="";
				for(String s:itemInfo)
					newValues+=s+"@";
				System.out.println("String====>>" +newValues);
				Amazon.cart.put(keyInfo,newValues);
				System.out.println(Amazon.cart);
				System.out.println("Item Quantity Changed");
				Cart.showCart();
			}else {
				byte confirm;
				System.out.println("Do you want to delete this item?");
				System.out.println("Press 1.YES 2.NO");
				confirm=Amazon.scn.nextByte();
				if(confirm==1) {
					Amazon.cart.remove(keyInfo);
					Cart.showCart();
					System.out.println("Item Removed from the cart!!!");
				}
				else if(confirm==2)
					Cart.showCart();
				else {
					System.err.println("Invalid Option Choosen!!!");
					Cart.showCart();
				}
			}
			
		}
		else {
			System.err.println("Item Code Not Found!!!");
			Cart.showCart();
		}
	}	
}
