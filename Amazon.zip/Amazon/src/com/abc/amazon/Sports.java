package com.abc.amazon;

public class Sports {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
