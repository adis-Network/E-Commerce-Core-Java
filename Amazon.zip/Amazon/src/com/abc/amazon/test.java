package com.abc.amazon;
import java.io.IOException;
import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        
  
          String s = null ;
           
        while(true){
            System.out.print( "AMAZON PROVIDING 10% of ON ALL ITEMS          ");
            try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           
        }
	}
}
