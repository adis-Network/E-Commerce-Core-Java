package com.abc.amazon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


public class DBConnection {
	static Connection con=null;
	static Statement stmt=null;
	ResultSet rs;
	
	public static Statement getConnection(){
		ResourceBundle rb=ResourceBundle.getBundle("com.abc.utility.accessDb");
		String url=rb.getString("url");
		String usr=rb.getString("usr");
		String pwd=rb.getString("pwd");
		try{
			 Class.forName("com.mysql.jdbc.Driver");
			 con=DriverManager.getConnection(url,usr,pwd);  
			 stmt=con.createStatement(); 
		}
		catch(ClassNotFoundException|SQLException e){ System.out.println("Class nai mil rahi hai!!!");}  
		return stmt;
	}
	

}
