package com.abc.amazon;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Amazon
{
	static Scanner scn;
	static String name="";
	static String email="";
	static int cartItemCounter=0;
	static String formattedDate;
	public static HashMap<String,String> cart=new HashMap<String,String>();
	public static void header() {
		System.out.println();
		getDate();
		System.out.printf("%25s %n","              ************************************************************************************************************");
		System.out.printf("%68s","AMAZON.COM");
		System.out.printf("%48s %n",name+"---> My Cart("+cartItemCounter+")");
		System.out.printf("%25s %n","              ************************************************************************************************************");	
	}

	public static void exit() {
		int choice = 0;
		System.out.println("Are you Sure you want exit? (1.Yes 2.No) \n");
		choice=scn.nextInt();
		if(choice==1) {
			if(cart.size()>0) {
				Cart.showCart();
			}else {
			System.out.println("Thank for Visting Amazon!!!!!");
			System.exit(0);
			}
		}else if(choice==2) {
			firstView();
		}
		else {
			System.err.println("Invalid Option Entered");
			exit();
		}
	}

	public static void getDate() {
		Date date = new Date();
		String strTimeFormat = "hh:mm:ss a";
		String strDateFormat="dd-MMM-yyyy";
		DateFormat timeFormat = new SimpleDateFormat(strTimeFormat);
		DateFormat dateFormat=new SimpleDateFormat(strDateFormat);
		String formattedTime= timeFormat.format(date);
		formattedDate= dateFormat.format(date);
		System.out.printf("%67s","Press : $ --> Cart | # --> Previous Menu | @ --> Exit");
		System.out.printf("%39s",formattedDate);
		System.out.printf("%15s %n",formattedTime);
	}

	public static boolean emailValidation(String email) {
		String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}
	public static boolean nameValidation(String name) {
		String regex = "^[a-zA-Z\\\\s]*$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}

	public static void firstView()
	{
		System.out.println();
		System.out.println();

		boolean b =  true;
		while(b)
		{
			header();
			System.out.println("\n----> Welcome Mr/Ms. "+name);
			System.out.println("\n\n");
			System.out.println("Looking Out For Categories : ");
			System.out.println("1. Electronics");
			System.out.println("2. Clothing");
			System.out.println("3. Groceries");
			System.out.println("4. Sports");
			System.out.println("5. Books and Audible");
			System.out.println("6. Toys and Baby Products");
			System.out.println("7. Gift Cards");
			System.out.println("8. Art, Handicraft and Collectibles\n");
			System.out.print("Please Choose a Category___");

			String inputView1 = scn.next();
			if(inputView1.equals("1"))
			{
				Electronics.electronicShowMenu();
				b=false;
			}
			else if(inputView1.equals("2"))
			{
				Clothing.clothingShowMenu();
				b=false;
			}
			else if(inputView1.equals("3"))
			{
				
				header();
				System.err.printf("%n %n %90s","Groceries : SORRY!!! OUT OF STOCK...........\n\n");
				b=false;
				firstView();
			}
			else if(inputView1.equals("4"))
			{
				header();
				System.err.printf("%n %n %90s","Sports : SORRY!!! OUT OF STOCK...........\n\n");
				b=false;
				firstView();
			}
			else if(inputView1.equals("5"))
			{
				header();
				System.err.printf("%n %n %90s","Books and Audible : SORRY!!! OUT OF STOCK...........\n\n");
				b=false;
				firstView();
				
			}
			else if(inputView1.equals("6"))
			{
				header();
				System.err.printf("%n %n %90s","Toys and Baby Products : SORRY!!! OUT OF STOCK...........\n\n");
				b=false;
				firstView();
			}
			else if(inputView1.equals("7"))
			{
				header();
				System.err.printf("%n %n %90s","Gift Cards : SORRY!!! OUT OF STOCK...........\n\n");
				b=false;
				firstView();
			}
			else if(inputView1.equals("8"))
			{
				header();
				System.err.printf("%n %n %90s","Art, Handicraft and Collectibles : SORRY!!! OUT OF STOCK...........\n\n");
				b=false;
				firstView();
			}
			else if(inputView1.equals("$"))
			{
				Cart.showCart();
			}
			else if(inputView1.equals("#"))
			{
				System.err.println("\n\nYou are in Main Menu <---> Unable to perform this operation right now!!!");
				firstView();
			}
			else if(inputView1.equals("@"))
			{
				exit();
			}
			else 
			{        
				System.out.println("Invalid Input");
			}
		}

	}
	
	synchronized static void display() 
    { 
         String s= "   OFFERS : ***Refurbished Mobiles Exchange Bonus upto Rs.1000*** ***Upto 200Rs Cashback on above 2000Rs Shopping*** ***Free Home Delivery***";
         String ss[]=s.split(" ");
        for (int i = 0; i < ss.length; i++) {           
            	try {
					Thread.sleep(600); 
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}       
                    System.err.print(ss[i]+ " "); 
            } 
        }   
	
	public static void main(String[] args)
	{
		header();
		display();
		scn = new Scanner(System.in);
		byte count=0;
		System.out.println();
		System.out.println();
		do {
		if(count>0)
		System.err.println("ERROR!!! - Please Enter a valid Name(Only Alphabets and Spaces allowed)\n");
		System.out.println("Enter Your Name :");
		name=scn.nextLine();
		count++;
		}while(!(nameValidation(name)));
		
		System.out.println();
		count=0;
		do {
			if(count>0)
			System.err.println("ERROR!!! - Please Enter a valid EmailID(ex: adil@gmail.com)\n");
			System.out.println("Enter Your Email :");
			email=scn.nextLine();
			count++;
			}while(!(emailValidation(email)));
		System.out.println();
		System.out.println();
		firstView();
	}
}
