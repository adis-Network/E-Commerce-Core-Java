package com.abc.amazon;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
public class Electronics
{
	public static void electronicShowMenu()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println();
		System.out.println();
		System.out.println("*****Welcome to Electronic*****");
		System.out.println();
		System.out.println("1. Mobile");
		System.out.println("2. Tv");
		System.out.println("3. Speakers");
		System.out.println("4. Laptops");
		System.out.println("5. Other Electronic Equipments");
		String s = scn.next();
		if(s.equals("1"))
		{
			showMobiles();
		}
		else if(s.equals("2"))
		{
			showTv();
		}
		else if(s.equals("3"))
		{
		   showSpeakers();
		}
		else if(s.equals("4"))
		{
		   //showSpeakers();
		}
		else if(s.equals("5"))
		{
		   //showSpeakers();
		}
		else if(s.equals("@"))
		{
			
			System.exit(1);
		}
		else if(s.equals("$"))
		{
			
			Cart.showCart();
		}
		else if(s.equals("#"))
		{
			Amazon.firstView();
		}
		else {
			System.err.println("Invalid Option Selected");
			Amazon.firstView();
		}
	}

	private static void showSpeakers() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** SPEAKERS *******");
		showElectronicDetails("Male","TShirts");

		
	}

	private static void showTv() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** TELEVISIONS *******");
		showElectronicDetails("Male","TShirts");

	}

	private static void showMobiles() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** MOBILE PHONES BRANDS *******");
		System.out.println("1. Samsung");
		System.out.println("2. Iphone");
		System.out.println("3. Motorola");
		System.out.println("4. MI");
		System.out.println("5. onePlus");
		System.out.println("6. Oppo");
		System.out.println("7. Vivo");
		System.out.println("Select Your Prefered Brand");
		char selection=Amazon.scn.next().charAt(0);
		System.out.println();
		System.out.printf("%35s %n%n","****** MOBILE PHONES *******");
		if(selection=='1')
		showElectronicDetails("Mobile","Samsung");
		else if(selection=='2')
		showElectronicDetails("Mobile","Iphone");
		else if(selection=='3')
			showElectronicDetails("Mobile","Motorola");
		else if(selection=='4')
			showElectronicDetails("Mobile","MI");
		else if(selection=='5')
			showElectronicDetails("Mobile","TShirts");
		else if(selection=='6')
			showElectronicDetails("Mobile","onePlus");
		else if(selection=='7')
			showElectronicDetails("Mobile","Vivo");
		else if(selection=='#')
			electronicShowMenu();
		else if(selection=='@')
			Amazon.exit();
		else if(selection=='$')
			Cart.showCart();
		else {
			System.err.println("Invalid Option Entered!!!");
			showMobiles();
		}
	}


	
	public static void showElectronicDetails(String type,String brand) {
		HashMap<String, String> itemMap=new HashMap<String, String>();

		int i=1;
		//Fetching Data from DB and Storing on Collections(HashMap)
		Statement stmt=DBConnection.getConnection();
		try {
			
			ResultSet rs = stmt.executeQuery("select * from mobiles where type='"+type+"' and brand='"+brand+"'");
			while(rs.next())
			{
				itemMap.put(rs.getString(2),(rs.getString(2)+"@"+rs.getString(3)+"@"+rs.getString(4)+"@"+rs.getInt(5)));
				i++;
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} 

		//Displaying Item Information on Screen
		System.out.printf("%1s %20s %30s %n%n","Item Code","Product Name","Price per piece");
		i=1;
		Set set = itemMap.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) {
			Map.Entry mentry = (Map.Entry)iterator.next();
			String[] value=((String)mentry.getValue()).split("@");
			System.out.format("%-7s %-40s %-8s %n", i, value[0] , "Rs."+value[3]);
			i++;
		}
		System.out.println();
		System.out.println("Enter Item Code to Buy an Item.");
		char item=Amazon.scn.next().charAt(0);
		if(item=='$')
		{
			Cart.showCart();
		}
		else if(item=='#')
			showMobiles();
		else if(item=='@')
			Amazon.exit();
		else {
			System.out.println("Enter Quantity?");
			int qty=Amazon.scn.nextInt();
			if(qty>0) {
				addClothToCart(itemMap,item,qty);
				showMobiles();
			}
			else {
				System.err.println("ERROR : Invalid Quantity... Please select again!!!");
				showMobiles();
			}
		}

	}
	
	//Method to add Clothes to the cart

	private static void addClothToCart(HashMap<String, String> myMap, char item, int qty) {
		String keyInfo = null;
		int j=1;
		// Keys of HashMap
		for ( String key : myMap.keySet() ) {
			if(j==Character.getNumericValue(item)) {
				keyInfo=key;
				break;
			}
			j++;
		}

		//Adding item to the cart

		if(Amazon.cart.containsKey(keyInfo)){
			String itemInfo[]=Amazon.cart.get(keyInfo).split("@");
			itemInfo[4]=String.valueOf(Integer.parseInt(itemInfo[4])+qty);
			Amazon.cart.put(keyInfo, (myMap.get(keyInfo)+"@"+itemInfo[4]));
		}
		else {
			System.out.println("key:"+keyInfo);
			System.out.println("Value"+myMap.get(keyInfo));
			Amazon.cart.put(keyInfo, (myMap.get(keyInfo)+"@"+qty));
			Amazon.cartItemCounter++;
		}

		System.out.println("--> "+keyInfo+" added to cart!!!");
	}

	
}