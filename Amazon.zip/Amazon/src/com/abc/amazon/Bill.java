package com.abc.amazon;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Bill {

	public static void Bill1() {
		
		System.out.println();
		double gst=Cart.grandTotal*0.12;
		System.out.println("\n\n\n\n");
		System.out.printf("%85s","AMAZON BUSSINESS INVOICE");
		System.out.println();
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.printf("%50s %60s %n","Invoice ID :#4568654","Order No : #987456");
	    System.out.printf("%50s %60s %n","Customer Name: "+Amazon.name,"Amount Due : "+Cart.grandTotal);
	    System.out.printf("%50s %60s %n","Payement Due by : "+Amazon.formattedDate,"Promos & Discounts : 0.0");
	    System.out.printf("%50s %60s %n","Email : "+Amazon.email,"Shipping Charges : 0.0");
	    System.out.printf("%50s %60s %n","","%GST : "+gst);

	    
	    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	    System.out.println();
	    System.out.println();
		System.out.printf("%30s %n","                                     <-------------------------- Purchased Item History ---------------------------->               ");
		System.out.println();



		System.out.println("           --------------------------------------------------------------------------------------------------------------------------               ");
		System.out.printf("%21s %20s %46s %14s %12s %12s %n%n","ITEM CODE","PRODUCT NAME","CATEGORY","PRICE", "QUANTITY","TOTAL");
		System.out.println("           --------------------------------------------------------------------------------------------------------------------------               ");

		int i=1;
		Set set = Amazon.cart.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) { 
			Map.Entry mentry = (Map.Entry)iterator.next();
			String[] value=((String)mentry.getValue()).split("@");
			double total=  Double.parseDouble(value[3]) *Double.parseDouble(value[4]);
			System.out.format("%21s %-60s %-15s %-12s %-13s %-1s %n", i+"     ", value[0] ,value[2] ,"Rs."+value[3],value[4],total);
			i++;
		}
		System.out.println();
	    System.out.printf("%90s %n%n%n","GRAND TOTAL : Rs."+(Cart.grandTotal+gst));
	 
	    System.out.printf("%80s","****THANK YOU****");
	}
 
}
