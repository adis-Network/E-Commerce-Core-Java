package com.abc.amazon;

public class Groceries {

	
}
