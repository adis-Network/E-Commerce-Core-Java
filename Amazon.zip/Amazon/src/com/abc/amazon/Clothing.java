package com.abc.amazon;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Clothing {
	static Scanner scn = new Scanner(System.in);
	
	//Clothing Menu
	public static void clothingShowMenu() {
		Amazon.header();
		Scanner scn = new Scanner(System.in);
		System.out.println();
		System.out.println();
		System.out.println("*****Welcome to clothing*****");
		System.out.println();
		System.out.println("Are You : ");
		System.out.println("Press 1 for Male Section ");
		System.out.println("Press 2 for Female Section ");
		System.out.println();
		String s = scn.next();
		if(s.equals("1"))
		{
			showMale();
		}
		else if(s.equals("2"))
		{
			showFemale();
		}
		else if(s.equals("#"))
		{
			Amazon.firstView();
		}
		else if(s.equals("$"))
		{
			Cart.showCart();
		}
		else if(s.equals("@"))
		{	
			Amazon.exit();
		}	
		else {
			System.err.println("ERROR : Invalid Option Selected!!!");
			
			clothingShowMenu();
		}
	}

	//MainMenu->Clothing->Female
	private static void showMale() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println("*****Welcome to clothing - Male Section*****");
		System.out.println();
		System.out.println("Are You : ");
		System.out.println("1. Men's Shirts");
		System.out.println("2. Men's Pants");
		System.out.println("3. Men's T Shirts");
		System.out.println("4. Men's Kurtas");
		System.out.println("Planning to go back press #.");
		System.out.println("Want to see your wish list !! Cart press $.");
		System.out.println("Planning to Come Next time !! Exit press @.");
		String s = scn.next();
		if(s.equals("1"))
		{
			menShirts();
		}
		else if(s.equals("2"))
		{
			menPants();
		}
		else if(s.equals("3"))
		{
			menTShirts();
		}
		else if(s.equals("4"))
		{
			menKurtas();
		}
		else if(s.equals("#"))
		{
			clothingShowMenu();
		}
		else if(s.equals("$"))
		{
			Cart.showCart();
		}
		else if(s.equals("@"))
		{
			Amazon.exit();
		}	
		else {
			System.err.println("ERROR : Invalid Option Selected!!!");
			showMale();
		}
	}



	private static void showFemale() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println("*****Welcome to clothing - Male Section*****");
		System.out.println();
		System.out.println("Are You : ");
		System.out.println("1. Female's Kurti");
		System.out.println("2. Female's Saree");
		System.out.println("3. Female's T Shirts");
		System.out.println("4. Female's Jeans/Legging");
		System.out.println("Planning to go back press #.");
		System.out.println("Want to see your wish list !! Cart press $");
		System.out.println("Planning to Come Next time !! Exit press @");
		String s = scn.next();
		if(s.equals("1"))
		{
			womenKurta();
		}
		else if(s.equals("2"))
		{
			womenSaree();
		}
		else if(s.equals("3"))
		{
			womenTShirts();
		}
		else if(s.equals("4"))
		{
			womenJeans();
		}
		else if(s.equals("#"))
		{
			clothingShowMenu();
		}
		else if(s.equals("$"))
		{
			Cart.showCart();
		}
		else if(s.equals("@"))
		{
			Amazon.exit();
		}	
		else {
			System.err.println("ERROR : Invalid Option Selected!!!");
			showFemale();
		}
	}

	private static void womenJeans() {
		// TODO Auto-generated method stub
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** WOMEN'S JEANS/LEGGINGS *******");
		showClothDetails("Female","Pants");
		
	}

	private static void womenTShirts() {
		// TODO Auto-generated method stub
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** WOMEN'S T-SHIRTS *******");
		showClothDetails("Female","TShirts");
		
	}

	private static void womenSaree() {
		// TODO Auto-generated method stub
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** WOMEN'S SAREE *******");
		showClothDetails("Female","Saree");
		
	}

	private static void womenKurta() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** WOMEN'S KURTIS *******");
		showClothDetails("Female","Kurta");
		
	}

	private static void menShirts() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** MEN'S SHIRTS *******");
		showClothDetails("Male","Shirts");
	}


	private static void menPants() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** MEN'S PANTS/JEANS *******");
		showClothDetails("Male","Pants");
	}

	private static void menTShirts() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** MEN'S T-SHIRTS *******");
		showClothDetails("Male","TShirts");

	}

	private static void menKurtas() {
		Amazon.header();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.printf("%35s %n%n","****** MEN'S KURTAS *******");
		showClothDetails("Male","Kurta");
			}




	
	public static void showClothDetails(String gender,String type) {
		HashMap<String, String> itemMap=new HashMap<String, String>();

		int i=1;
		//Fetching Data from DB and Storing on Collections(HashMap)
		Statement stmt=DBConnection.getConnection();
		try {
			
			ResultSet rs = stmt.executeQuery("select * from clothes where forr='"+gender+"' and descc='"+type+"'");
			while(rs.next())
			{
				itemMap.put(rs.getString(2),(rs.getString(2)+"@"+rs.getString(3)+"@"+rs.getString(4)+"@"+rs.getInt(5)));
				i++;
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} 

		//Displaying Item Information on Screen
		System.out.printf("%1s %20s %30s %n%n","Item Code","Product Name","Price per piece");
		i=1;
		Set set = itemMap.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) {
			Map.Entry mentry = (Map.Entry)iterator.next();
			String[] value=((String)mentry.getValue()).split("@");
			System.out.format("%-7s %-40s %-8s %n", i, value[0] , "Rs."+value[3]);
			i++;
		}
		System.out.println();
		System.out.println("Enter Item Code to Buy an Item.");
		char item=scn.next().charAt(0);
		if(item=='$')
		{
			Cart.showCart();
		}
		else if(item=='#')
			showMale();
		else if(item=='@')
			Amazon.exit();
		else {
			try {
			System.out.println("Enter Quantity?");
			int qty=scn.nextInt();
			if(qty>0) {
				addClothToCart(itemMap,item,qty);
				clothingShowMenu();
			}
			else {
				System.err.println("ERROR : Invalid Quantity... Please select again!!!");
				clothingShowMenu();
			}
			}
			catch(Exception e) {
				System.out.println("Invalid Input");
				Amazon.firstView();
			}
		}

	}
	
	//Method to add Clothes to the cart

	private static void addClothToCart(HashMap<String, String> myMap, char item, int qty) {
		String keyInfo = null;
		int j=1;
		// Keys of HashMap
		for ( String key : myMap.keySet() ) {
			if(j==Character.getNumericValue(item)) {
				keyInfo=key;
				break;
			}
			j++;
		}

		//Adding item to the cart

		if(Amazon.cart.containsKey(keyInfo)){
			String itemInfo[]=Amazon.cart.get(keyInfo).split("@");
			itemInfo[4]=String.valueOf(Integer.parseInt(itemInfo[4])+qty);
			Amazon.cart.put(keyInfo, (myMap.get(keyInfo)+"@"+itemInfo[4]));
		}
		else {
			System.out.println("key:"+keyInfo);
			System.out.println("Value"+myMap.get(keyInfo));
			Amazon.cart.put(keyInfo, (myMap.get(keyInfo)+"@"+qty));
			Amazon.cartItemCounter++;
		}

		System.out.println("--> "+keyInfo+" added to cart!!!");
	}
	
	
	
}





